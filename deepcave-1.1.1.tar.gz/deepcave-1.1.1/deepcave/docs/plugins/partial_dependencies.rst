Partial Dependencies
====================

This plugin is capable of answering following questions:

* How does the objective change wrt one or two hyperparameters? For example, does the accuracy
  increase if the learning rate decreases?
* Do multiple trials show similar behavior?


.. warning:: 
    This page is under construction.


.. image:: ../images/plugins/partial_dependencies.png
